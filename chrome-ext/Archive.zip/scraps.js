
//each of these lines, when run one after another, deletes a comment

document.getElementsByClassName("dropdown-trigger style-scope ytd-menu-renderer")[0].click(); 

document.getElementsByClassName("yt-simple-endpoint style-scope ytd-menu-navigation-item-renderer")[1].click();

document.getElementsByClassName("yt-simple-endpoint style-scope yt-button-renderer")[1].click()

